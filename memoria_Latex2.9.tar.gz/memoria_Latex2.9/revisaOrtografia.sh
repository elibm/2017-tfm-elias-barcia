ispell -d spanish -T utf8 $1
